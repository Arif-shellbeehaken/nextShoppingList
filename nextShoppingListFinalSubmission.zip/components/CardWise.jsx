import React from "react";

const CardWise = () => {
  return <div></div>;
};

export default CardWise;
