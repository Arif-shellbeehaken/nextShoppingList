
import NavbarSection from '../components/NavbarSection';
import ShoppingItem from '../components/ShoppingItem';

export default function Home() {

  return (
    <main>
        <ShoppingItem />
    </main>
  );
}
